﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrviProjekat {
    /* 
       (<authors>|<title>|<subjects>|<publisher>|<key>|<work_year>|<edition_year>)
       {&(<authors>|<title>|<subjects>|<publisher>|<key>|<work_year>|<edition_year>)}
       [&<sort>]
       [&<lang>] 
     */
    /*
        Argument descriptions:
            sort          - directly passed to the OLAPI query
            lang          - two letter acronym of the desired language. 
                            Two letter acronym will promote matching results,
                            (three letter one will act as a strict query filter (*) - probably will not implement as it doesn't fit nicely in this architecture I have here)
            work_year     - solr range for the year the work was first published (*)
            edition_year  - solr range for the year desired edition was published (*)
            authors       - comma separated list of a subset of a title's authors (*)
            title         - a title to search for (*)
            subjects      - comma separated list of a subset of a title's subjects (*)
            publisher     - publisher of a title's editions (*)
            key           - the OLAPI key of a title (*)
                  
        *Multi-valued queries on this argument translate to an OR chain
     */
    public class QueryTranslator {
        public QueryTranslator() {
            sourceUnits = new SortedDictionary<string, Unit> {
                ["key"]          = new Unit("k=", "key:"),
                ["title"]        = new Unit("t=", "title:"),
                ["authors"]      = new Unit("a=", "author:", unsorted => string.Join(',', unsorted.Split(',').Select(value => value.Trim()).Distinct().Order()), (prefix, values) => string.Join(" AND ", values.Split(',').Select(value => prefix + value.Trim()))),
                ["subjects"]     = new Unit("s=", "subject:", unsorted => string.Join(',', unsorted.Split(',').Select(value => value.Trim()).Distinct().Order()), (prefix, values) => string.Join(" AND ", values.Split(',').Select(value => prefix + value.Trim()))),
                ["publisher"]    = new Unit("p=", "publisher:"),
                ["work_year"]    = new Unit("w=", "first_publish_year:"),
                ["edition_year"] = new Unit("e=", "publish_year:"),
                ["sort"]         = new Unit("o=", "sort=", false),
                ["lang"]         = new Unit("l=", "lang=", false),
                ["fields"]       = new Unit("f=", "fields=", false),
            };
            caseInsensitive = new HashSet<string>(["title", "authors", "subjects", "publisher", "lang", "fields"]);
        }

        private class Unit {
            public Unit(string srcKey, string trKey, bool isSolr = true) 
            : this(
                srcKey, 
                trKey,
                value => value.Trim(),
                (prefix, value) => prefix + value.Trim(), 
                isSolr) {
            }
            public Unit(string srcKey, string trKey, Func<string, string> canonicalFormatter, Func<string, string, string> atomFormatter, bool isSolr = true) {
                IsSolr = isSolr;
                sourcePrefix = srcKey;
                translatedPrefix = trKey;
                TranslationComponent = "";
                CanonicalValueFormat = canonicalFormatter;
                TranslationAtomFormat = atomFormatter;
            }

            public bool IsSolr { get; private set; }
            public string CanonicalSubquery { get => string.Join('&', sourceSubqueries.ToArray()); /* vec je sortirano */ }
            public string TranslationComponent { get; private set; }
            public Func<string, string> CanonicalValueFormat { private get; set; }
            public Func<string, string, string> TranslationAtomFormat { private get; set; }
            public Func<string[], string> TranslationFunc { private get; set; }

            public void Add(string[] values) {
                foreach (string value in values)
                    sourceSubqueries.Add(sourcePrefix + CanonicalValueFormat.Invoke(value));
                string delimiter = IsSolr ? " OR " : "&";
                string[] grouping = IsSolr ? [ "(", ")" ] : [ "", "" ];
                TranslationComponent += TranslationComponent != "" ? delimiter : "";
                TranslationComponent += string.Join(delimiter, values.Select(value => grouping[0] + TranslationAtomFormat.Invoke(translatedPrefix, value) + grouping[1]));
            }

            private string sourcePrefix;
            private string translatedPrefix;
            private SortedSet<string> sourceSubqueries = new();
        }

        public string CanonicalSource {
            get => string.Join('&', sourceUnits.Values.Select(unit => unit.CanonicalSubquery).Where(subq => subq != "").Order());
        }
        public string TranslatedQuery {
            get {
                var usedFields = sourceUnits.Values.Where(unit => unit.TranslationComponent != "");
                string solr = "q=" + string.Join(" AND ", usedFields.Where(unit => unit.IsSolr).Select(unit => $"({unit.TranslationComponent})"));
                string additional = string.Join('&', usedFields.Where(unit => !unit.IsSolr).Select(unit => unit.TranslationComponent));
                return solr + (additional != "" ? "&" + additional : "");
            }
        }

        public void Translate(NameValueCollection query) {
            foreach (string key in query.AllKeys) {
                if (!sourceUnits.ContainsKey(key))
                    continue;
                sourceUnits[key].Add(query.GetValues(key).Select(value => caseInsensitive.Contains(key) ? value.ToLower() : value).ToArray());
            }
        }

        private SortedDictionary<string, Unit> sourceUnits;
        private HashSet<string> caseInsensitive;
    }
}
