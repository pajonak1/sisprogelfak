﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Design;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace PrviProjekat {
    public class OLServer {
        public OLServer(string serverPath, int cacheSize) {
            this.serverPath = serverPath;
            httpL.Prefixes.Add(serverPath);
            cache = new LRUCache(cacheSize);
        }

        public bool Start() {
            try {
                httpL.Start();
            }
            catch (Exception e) {
                Logger.EchoLog(Logger.Event.Critical, $"Server failed to start: {e.Message}");
                return false;
            }
            Logger.EchoLog(Logger.Event.Notify, $"Started server at web address {serverPath}");
            ThreadPool.QueueUserWorkItem(Listen);
            return true;
        }
        public void Stop() {
            httpL.Stop();
            httpL.Close();
            Logger.EchoLog(Logger.Event.Notify, "Server stopped successfully.");
        }

        private void Listen(object? dummy) {
            while (httpL.IsListening) {
                try {
                    HttpListenerContext request = httpL.GetContext();
                    Logger.Log(request.Request, "Request recieved");
                    ThreadPool.QueueUserWorkItem(Process, request);
                }
                catch (Exception e) {
                    Logger.Log(Logger.Event.Error, e.Message);
                }
            }
            Logger.Log(Logger.Event.Notify, "Server has stopped listening");
        }
        private void Process(object? request) {
            bool responseSent = false;
            HttpListenerContext context = (HttpListenerContext) request!;
            Logger.Log(context.Request, "Request started processing");
            
            // status code dodaj mozda
            bool requestRight = false;
            string rawUrl = context.Request.RawUrl !;
            ResponeseData cachedResponse = null;
            QueryTranslator translator = new QueryTranslator();

            try {
                string arguments = context.Request.Url!.AbsolutePath.ToLower();
                // log?
                
                if (arguments == "/") {
                    SendResponse(context.Response, "Search OpenLibrary by sending a query to ./search.");
                    responseSent = true;
                }
                else if (arguments == "/search") {
                    translator.Translate(context.Request.QueryString);
                    Logger.EchoLog(Logger.Event.Notify, translator.CanonicalSource);
                    Logger.EchoLog(Logger.Event.Notify, translator.TranslatedQuery);
                    OLRequest subscription = null;

                    lock (_lock) {
                        if (cache.Contains(translator.CanonicalSource)) {
                            Logger.EchoLog(Logger.Event.Notify, "Request was cached");
                            cachedResponse = cache[translator.CanonicalSource];
                        }
                        else if (!requestsToOLAPI.ContainsKey(translator.CanonicalSource)) {
                            Logger.EchoLog(Logger.Event.Notify, "Request not cached, but obtained API call privilege");
                            requestsToOLAPI.Add(translator.CanonicalSource, new OLRequest());
                            requestRight = true;
                        }
                        else {
                            subscription = requestsToOLAPI[translator.CanonicalSource];
                            subscription.Subscribe();
                        }
                    }
                    
                    if (!requestRight && cachedResponse == null) {
                        lock (subscription.Lock) {
                            Logger.EchoLog(Logger.Event.Notify, "Waiting for the first thread to make the API call");
                            // Mora se ograditi jer inace moze nastupiti deadlock u veoma specificnoj
                            // situaciji: ukoliko se PulsaAll izvrsi kada se neka nit zaustavi
                            // izmedju ovog i prethodnog lock-a
                            // while treba jer navodno OS moze sporadicno da probudi niti koje se blokiraju na wait?...
                            while (subscription.Response == null && subscription.FetcherAborted == false) 
                                Monitor.Wait(subscription.Lock);
                            if (subscription.Response != null) {
                                // ne cita se iz cache-a jer teoretski dok nit dobije pravo pristupa, ako je server veoma opterecen
                                // moguce je da zahtev bude u medjuvremenu izbacen
                                cachedResponse = subscription.Response;
                                if (subscription.SubscriberCount > 1)
                                    subscription.Unsubscribe();
                                else
                                    lock (_lock)
                                        requestsToOLAPI.Remove(translator.CanonicalSource);
                            }
                            // moguce je da dodje do izuzetka/greske prilikom slanja zahteva
                            // u tom slucaju postoje dve opcije:
                            // 1) da se jednoj niti koja ceka daje pravo da obavi API poziv
                            //      + mozda je problem bio sporadicne prirode, samo jedan zahtev propada
                            //      - ako je problem na OpenLibrary strani, ovaj proces ce potrajati
                            /*
                            else {
                                Logger.EchoLog(Logger.Event.Notify, "API caller failed, obtained request privilege");
                                requestRight = true;
                                subscription.Unsubscribe();
                            }//*/
                            // 2) da sve niti obustave zahtev
                            else {
                                if (subscription.SubscriberCount > 1)
                                    subscription.Unsubscribe();
                                else
                                    lock (_lock)
                                        requestsToOLAPI.Remove(translator.CanonicalSource);
                                throw new Exception("API caller failed, aborting my request");
                            }//*/
                        }
                    }
                    if (cachedResponse != null) {
                        Logger.EchoLog(Logger.Event.Notify, "Sending cached response");
                        SendResponse(context.Response, cachedResponse);
                        responseSent = true;
                        return;
                    }
                    
                    Logger.EchoLog(Logger.Event.Request, "Sending request to OpenLibrary API");
                    if (!OLFetch(translator.TranslatedQuery, out string response)) {
                        SendResponse(context.Response, "Request failed (Internal serve error)", 500);
                        responseSent = true;
                        throw new WebException(response);
                    }
                    Logger.EchoLog(Logger.Event.Request, "Response acquired successfully");
                    JsonObject json = JsonNode.Parse(response).AsObject();
                    foreach (string field in responseJunk) {
                        json.Remove(field);
                    }
                    response = json.ToJsonString();
                    CacheSlot newEntry = new CacheSlot(translator.CanonicalSource, Encoding.UTF8.GetBytes(response), "application/json; charset=utf-8");
                    Logger.EchoLog(Logger.Event.Response, "Sending response");
                    SendResponse(context.Response, newEntry.Response);
                    responseSent = true;
                    lock (_lock) {
                        OLRequest myRequest = requestsToOLAPI[translator.CanonicalSource];
                        lock (myRequest.Lock) {
                            cache.Add(newEntry);
                            Logger.EchoLog(Logger.Event.Notify, $"Cached {newEntry.Body.Length} bytes of data");
                            myRequest.Response = newEntry.Response;
                            if (myRequest.SubscriberCount == 0)
                                requestsToOLAPI.Remove(translator.CanonicalSource);
                            else 
                                Monitor.PulseAll(myRequest.Lock);
                        }
                    }
                }
                else {
                    SendResponse(context.Response, "Request unrecognized", 404);
                    responseSent = true;
                }
            }
            catch (Exception e) {
                Logger.EchoLog(Logger.Event.Error, "Error while processing request -> " + e.Message);
                if (!responseSent)
                    SendResponse(context.Response, "Error occured, request terminated", 500);
            }
            finally {
                if (requestRight) {
                    lock (_lock) {
                        // Idealy this check shouldn't be needed though?
                        OLRequest myRequest = requestsToOLAPI.ContainsKey(translator.CanonicalSource) ? requestsToOLAPI[translator.CanonicalSource] : null;
                        if (myRequest != null && myRequest.Response == null) {
                            if (myRequest.SubscriberCount > 0) {
                                lock (requestsToOLAPI[translator.CanonicalSource].Lock) {
                                    myRequest.FetcherAborted = true;
                                    Monitor.PulseAll(requestsToOLAPI[translator.CanonicalSource].Lock);
                                }
                            }
                            else
                                requestsToOLAPI.Remove(translator.CanonicalSource);
                        }
                    }
                }
            }
        }
        private void SendResponse(HttpListenerResponse httpResponse, ResponeseData responese, int statusCode = 200)
            => SendResponse(httpResponse, responese.Body, responese.ContentType, statusCode);

        private void SendResponse(HttpListenerResponse httpResponse, string textResponse, int statusCode = 200)
            => SendResponse(httpResponse, new ResponeseData(textResponse), statusCode);

        private void SendResponse(HttpListenerResponse httpResponse, byte[] body, string contentType, int statusCode = 200) {
            httpResponse.StatusCode = statusCode;
            httpResponse.ContentType = contentType;
            httpResponse.ContentLength64 = body.Length;
            httpResponse.OutputStream.Write(body, 0, body.Length);
            httpResponse.OutputStream.Close();
            // log maybe
        }
        private bool OLFetch(string query, out string response) {
            bool fetched = false;
            string olUrl = apiQueryPrefix + query;
            HttpResponseMessage olResponse = null;
            try {
                olResponse = olClient.GetAsync(olUrl).Result;
                fetched = true;
                olResponse.EnsureSuccessStatusCode();
                response = olResponse.Content.ReadAsStringAsync().Result;
                return true;
            }
            catch (HttpRequestException e) {
                if (fetched) { 
                    response = olResponse.ReasonPhrase + $"({olResponse.StatusCode})";
                    return false;
                }
                response = "Open Library API GET request failed -> " + e.Message;
            }
            catch (Exception e) {
                response = "Open Library API GET request failed -> " + e.Message;
            }
            return false;
        }

        private readonly string serverPath;
        private object _lock = new();
        private LRUCache cache;
        private HttpClient olClient = new();
        private HttpListener httpL = new();
        private Dictionary<string, OLRequest> requestsToOLAPI = new();
        private const string apiQueryPrefix = "https://openlibrary.org/search.json?";
        private static readonly string[] responseJunk = {
            "start",
            "numFoundExact",
            "num_found",
            "documentation_url",
            "q",
            "offset"
        };
    }
}